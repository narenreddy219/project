# OneRec local metadata investigation workspace

- Use the OneRec metadata Skill at `.github/skills/onerec-metadata-resolver/SKILL.md` for configuration gap analysis.
- Work only with sanitized synthetic or explicitly authorized local files.
- No MCP, network operations, database connections, DML, DDL, writes to metadata inputs, or automatic production changes.
- Distinguish actual state, approved expected state, machine-checked differences and runtime causality.
- Cite actual JSON field paths and expected rule references; do not invent Oracle schema fields.
- Outputs must include gap matrix, evidence, RCA uncertainty, reviewed correction, verification and approval requirements.
