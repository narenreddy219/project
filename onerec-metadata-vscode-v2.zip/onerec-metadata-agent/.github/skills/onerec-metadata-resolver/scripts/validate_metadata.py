#!/usr/bin/env python3
"""Offline OneRec metadata actual-vs-expected rule validator. JSON only, no IO except local files."""
import argparse
import json
from pathlib import Path

_MISSING = object()
OPERATORS = {"equals", "not_equals", "one_of", "required", "absent"}
SEVERITIES = {"high", "medium", "low"}


def get_value(document, dotted_path):
    """Resolve a restricted dict-only path; no expressions, wildcards or evaluation."""
    if not isinstance(dotted_path, str) or not dotted_path or not all(
        part and part.replace("_", "").replace("-", "").isalnum()
        for part in dotted_path.split(".")
    ):
        return _MISSING
    value = document
    for part in dotted_path.split("."):
        if not isinstance(value, dict) or part not in value:
            return _MISSING
        value = value[part]
    return value


def is_populated(value):
    return value is not _MISSING and value is not None and value != "" and value != [] and value != {}


def check_rule(actual, rule):
    path = rule.get("path")
    op = rule.get("op")
    severity = rule.get("severity", "medium")
    result = {
        "path": path,
        "operator": op,
        "severity": severity,
        "source_ref": rule.get("source_ref"),
        "rationale": rule.get("rationale"),
    }
    if not isinstance(path, str) or not path.startswith("metadata.") or op not in OPERATORS or severity not in SEVERITIES:
        return {**result, "status": "unknown", "reason": "Invalid rule path, operator or severity"}
    condition = rule.get("when")
    if condition is not None:
        if not isinstance(condition, dict) or not isinstance(condition.get("path"), str) or "equals" not in condition:
            return {**result, "status": "unknown", "reason": "Invalid conditional rule"}
        condition_value = get_value(actual, condition["path"])
        if condition_value is _MISSING:
            return {**result, "status": "unknown", "reason": "Condition field missing in actual metadata"}
        if condition_value != condition["equals"]:
            return {**result, "status": "not_applicable", "reason": "Rule condition does not apply"}
    actual_value = get_value(actual, path)
    present = actual_value is not _MISSING
    result["actual"] = actual_value if present else "<MISSING>"
    if "value" in rule:
        result["expected"] = rule["value"]
    if op in {"equals", "not_equals", "one_of"} and "value" not in rule:
        return {**result, "status": "unknown", "reason": "Expected value not supplied"}
    if op == "one_of" and not isinstance(rule["value"], list):
        return {**result, "status": "unknown", "reason": "one_of requires a list"}
    if op == "required":
        aligned = is_populated(actual_value)
    elif op == "absent":
        aligned = not present or actual_value is None
    elif not present:
        aligned = False
    elif op == "equals":
        aligned = actual_value == rule["value"]
    elif op == "not_equals":
        aligned = actual_value != rule["value"]
    else:
        aligned = actual_value in rule["value"]
    return {**result, "status": "aligned" if aligned else "gap_requires_review", "reason": "Rule check only; runtime causality not established"}


def validate(actual, expected):
    if not isinstance(actual, dict) or not isinstance(expected, dict):
        raise ValueError("Both inputs must be JSON objects")
    actual_scope, expected_scope = actual.get("scope"), expected.get("scope")
    if not isinstance(actual_scope, dict) or not isinstance(expected_scope, dict):
        return {"status": "invalid_scope", "read_only": True, "error": "Both documents must contain a scope object"}
    for field in ("recon_id", "feed_id", "environment"):
        a, e = actual_scope.get(field), expected_scope.get(field)
        if not is_populated(a) or not is_populated(e) or str(a) != str(e):
            return {"status": "invalid_scope", "read_only": True, "error": "Scope missing or differs: " + field,
                    "actual_scope": actual_scope, "expected_scope": expected_scope}
    rules = expected.get("rules")
    if not isinstance(rules, list) or not rules:
        return {"status": "no_verified_expectations", "read_only": True, "scope": actual_scope,
                "error": "Expected state needs at least one explicit rule"}
    authority = expected.get("authority") or {}
    claimed_approved = isinstance(authority, dict) and authority.get("status") == "approved" and all(
        is_populated(authority.get(k, _MISSING)) for k in ("type", "reference", "owner")
    )
    checks = []
    for index, rule in enumerate(rules):
        if not isinstance(rule, dict):
            checks.append({"index": index, "status": "unknown", "reason": "Rule must be a JSON object"})
        else:
            checks.append({"index": index, **check_rule(actual, rule)})
    summary = {status: sum(c["status"] == status for c in checks) for status in
               ("aligned", "gap_requires_review", "unknown", "not_applicable")}
    if not claimed_approved:
        status = "unverified_expected_state"
    elif summary["unknown"]:
        status = "incomplete_validation"
    elif summary["gap_requires_review"]:
        status = "gaps_require_review"
    else:
        status = "aligned_to_documented_expectations"
    return {
        "status": status,
        "read_only": True,
        "scope": actual_scope,
        "authority": {"claim": authority, "independently_verified": False},
        "summary": summary,
        "checks": checks,
        "causality": "not_established",
        "note": "A difference is not proof of defect. Verify expected-state approval and runtime evidence separately."
    }


def main():
    parser = argparse.ArgumentParser(description="Read-only actual vs approved expected-state metadata validation")
    parser.add_argument("--actual", required=True, help="Sanitized current/AS-IS metadata JSON")
    parser.add_argument("--expected", required=True, help="Approved TO-BE rule assertions JSON")
    parser.add_argument("--output", required=True, help="Destination for a new JSON report")
    args = parser.parse_args()
    actual_path, expected_path, out_path = [Path(p).resolve() for p in (args.actual, args.expected, args.output)]
    if len({actual_path, expected_path, out_path}) != 3:
        parser.error("Actual, expected and output must all be different files")
    for path in (actual_path, expected_path):
        if not path.is_file():
            parser.error("Missing JSON input: " + str(path))
    try:
        actual = json.loads(actual_path.read_text(encoding="utf-8"))
        expected = json.loads(expected_path.read_text(encoding="utf-8"))
        report = validate(actual, expected)
    except (ValueError, UnicodeDecodeError) as exc:
        parser.error(str(exc))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=True))


if __name__ == "__main__":
    main()
