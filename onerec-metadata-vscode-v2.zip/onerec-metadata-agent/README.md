# OneRec Metadata Resolver v2 - AS-IS versus TO-BE

Use VS Code + organization-approved GitHub Copilot Agent Mode to investigate local OneRec metadata without MCP. This starter combines a reusable Skill, a custom Copilot agent, synthetic example files and a standard-library-only Python validator. It does not connect to Oracle, retrieve live metadata or modify real configurations.

## What the Skill distinguishes

- **AS-IS (what we have)**: captured actual metadata at a known recon/feed/environment/version.
- **TO-BE (what we need)**: approved field-level source specifications, recon requirements and change records.
- **Gap**: actual metadata does not satisfy an explicit expected assertion; not automatically a defect.
- **RCA**: correlation of gaps with separate runtime/audit evidence and alternative explanations.

A previous successful run or a peer recon is **comparative evidence**, not necessarily an authoritative baseline. The four file/Olympus source combinations are intentionally out of scope for this starter.

## Run locally

Open this folder in VS Code (Python 3.9+ recommended). From the repository root run:

```sh
python tools/validate_metadata.py --actual examples/actual.json --expected examples/expected.json --output reports/gap-report.json
python -m unittest discover -s tests -v
```

The demo should produce two gaps (delimiter and missing EOD marker field), two aligned rules and an analysis status that requires review. The expected-state approval record is **synthetic** and is not authenticated by the code.

## Run with Copilot Agent Mode

Select the `metadata-resolver` custom agent in Copilot Chat, if enabled by your enterprise extension. Sample prompt:

> Use the OneRec Metadata Resolver Skill. Analyze `examples/actual.json` against `examples/expected.json`, run the local read-only validator, create a gap matrix with exact paths and source references, and distinguish confirmed differences from RCA hypotheses. Do not connect to Oracle or modify any metadata.

If your Copilot version does not load repository Skills/custom agents automatically, open the Skill file and point Copilot at it explicitly. Do not weaken organization policies to enable it.

## Add real sources safely

Map approved, sanitized Oracle JSON exports to the normalized `actual` structure **without asserting that example JSON keys are Oracle column names**. Map signed-off requirements to `expected.rules` and record source references. Confirm identifiers and environment match. Ask security/owners for authorization before enabling any access to organizational systems.

## Package layout

- `.github/skills/onerec-metadata-resolver/SKILL.md`: reusable workflow.
- `.github/agents/metadata-resolver.agent.md`: Copilot custom agent behavior.
- `tools/validate_metadata.py`: deterministic local read-only validator.
- `examples/actual.json` and `examples/expected.json`: synthetic metadata / approved claim only.
- `tests/test_metadata_resolution.py`: offline validation tests.
- `reports/`: generated reports only (ignored by git).

## Known limits

JSON only; XML requires separately approved normalization. No database integration, no source code analysis, no reconciliation engine invocation, no verified approval registry, and no automated fixes. Runtime root cause cannot be proven from config diffs alone.
