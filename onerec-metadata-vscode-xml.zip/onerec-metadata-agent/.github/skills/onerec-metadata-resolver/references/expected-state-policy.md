# Choosing what we need to have

## Decision hierarchy

| Evidence source | Use | Limitation |
|---|---|---|
| Signed-off source file specification | Normative feed parsing/readiness values | Confirm feed/version/environment match |
| Approved recon business rule | Normative matching, tolerance, date handling | Must map precisely to rule fields |
| Approved change request/metadata deployment manifest | Normative intended deployed values | Check effective release and date |
| Previously successful run of same recon/feed | Useful comparator | Success alone does not prove all fields are correct |
| BAU-vs-EZ or DEV-vs-UAT difference | Diagnostic lead | Do not treat one side as automatically correct |
| Similar recon's metadata | Pattern discovery | Not authoritative for the incident feed |

## What we have vs what we need

Define three independent categories:
1. **As-is facts:** exact values present in current metadata, with source and capture time.
2. **To-be assertions:** explicit approved requirements, mapped field-by-field; record reference and owner.
3. **Execution evidence:** observed files, audit statuses, parser results, row counts, matching metrics, timestamps.

Classify a result as one of:
- `aligned`: observed metadata satisfies a verified expectation.
- `gap_requires_review`: actual differs from a documented expected value; impact unconfirmed.
- `not_applicable`: conditional rule does not apply.
- `unknown`: no authoritative expectation / missing evidence / unsupported schema.
- `invalid_scope`: inputs refer to different recon/feed/environment.

## Approval gates
An agent may read sanitized metadata, compute differences and draft a proposed correction. A proposed value must have evidence. The agent must never execute configuration writes; humans with separately approved access must review implementation, validation and rollback. Explicitly say when approval claims cannot be authenticated from local files.

## No baseline available
If no approved expected file exists: summarize the current export, identify structural omissions that are provably invalid from verified schema, ask for the source contract or metadata manifest, and mark functional correctness **unknown**. Do not assume universal defaults (comma delimiter, IS_EOD, T+1, particular matching pass semantics).
