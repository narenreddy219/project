# Legacy JSON Mode (Optional)

XML is now the primary supported metadata input. See [xml-metadata.md](xml-metadata.md). This file describes only the optional legacy normalized JSON + rule format.

# Offline normalized input contracts (v2)

These **are prototype JSON field names, not verified Oracle database column names**. Real export mappings must be separately reviewed and approved. All examples must be sanitized.

## Actual / AS-IS

```json
{
  "scope": {"recon_id": "DEMO-30396", "feed_id": "DEMO-LEFT", "environment": "UAT"},
  "capture": {"source": "sanitized-config-export", "captured_at": "2026-11-19", "version": "sample"},
  "metadata": {
    "feed": {"format": "delimited", "delimiter": "|", "has_header": true},
    "readiness": {"mode": "eod_marker", "marker_field": null},
    "cpp": {"transformations": []},
    "scheduler": {"cob_rule": "T+1"}
  }
}
```

## Expected / TO-BE

```json
{
  "scope": {"recon_id": "DEMO-30396", "feed_id": "DEMO-LEFT", "environment": "UAT"},
  "authority": {"status": "approved", "type": "source_contract", "reference": "SYNTHETIC-SPEC-001", "owner": "Demo Feed Owner"},
  "rules": [
    {"path": "metadata.feed.delimiter", "op": "equals", "value": ",", "severity": "medium", "source_ref": "SYNTHETIC-SPEC-001", "rationale": "Demo source contract specifies comma"},
    {"path": "metadata.readiness.marker_field", "op": "required", "severity": "high", "source_ref": "SYNTHETIC-SPEC-001", "when": {"path": "metadata.readiness.mode", "equals": "eod_marker"}, "rationale": "Demo EOD mode requires a configured field"}
  ]
}
```

The example approval label is synthetic; it is NOT evidence of real Citi approval.

## Rule contract
- `path`: dot-separated path into actual JSON, e.g. `metadata.feed.delimiter` (no JSONPath, wildcards, expressions or arbitrary code).
- `op`: `equals`, `not_equals`, `one_of`, `required`, `absent`.
- `value`: required for equality or membership checks; `one_of` expects an array.
- `when`: optional condition `{ "path": "...", "equals": value }`; rules not meeting it are not applicable.
- `severity`: `high`, `medium`, `low` (prioritization only, never proof of impact).
- `source_ref`: explicit traceability to contract, Jira requirement, signed-off mapping, or approved version.
- `rationale`: short explanation of the expected behavior.

Treat a missing field as different from an explicitly empty field. `required` means not missing, null, blank string, empty array or empty object. For `absent`, both omitted and null are treated as absent by the prototype; document stricter requirements before production use.

The expected `authority.status=approved` is only a user-supplied assertion. The validator verifies its presence but cannot authenticate approvals; the engineer must confirm the source externally.

## Scope rules
Always match recon ID, feed ID and environment when supplied in the expected file. Reject cross-feed/cross-recon comparisons. A different environment needs an explicitly scoped expected state; do not silently compare DEV to PROD as authoritative.

## Security
No raw source records, PII, secrets, tokens, usernames/passwords, production logs or live database credentials. Local report outputs must use approved workspaces and must not overwrite inputs.
