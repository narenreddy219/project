# OneRec diagnostic playbooks: from what exists to what is required

## Feed format and delimiter
AS-IS: file format, delimiter, header rows, actual parser config, observed columns. TO-BE: signed-off feed layout and version. Evidence: sanitized sample parse, record/column counts. Distinguish metadata misconfiguration from hardcoded parser behavior. Never presume comma is correct.

## Completion and readiness (EOD, trailer, file pair)
AS-IS: detection mode, EOD field, trailer count or completion marker config, merger wait state. TO-BE: actual source delivery contract including record count semantics. Evidence: last message/marker, batch count, audit state. Avoid inventing EOM/trailer data. A file-pair marker such as .dat/.ok is valid only when explicitly required by that feed.

## CPP transformation
AS-IS: field mappings, UDF names, transformation order and parse types. TO-BE: approved field derivation mapping and transformation contract. Evidence: sanitized transformed output and CPP diagnostics. A wrong field reference (e.g., value_amount versus value_amt) is a hypothesis until verified on input schema/code.

## Scheduler and COB rules
AS-IS: schedule, runtime flags, holidays, run date and COB date. TO-BE: approved business calendar, T+1/T+2 rules, dependencies. Evidence: trigger history and scheduler/launcher state. Date or feed differences are not automatically metadata defects.

## Recon matching passes
AS-IS: pass order, inclusion/exclusion, duplicate handling, tolerance, break reason config. TO-BE: signed-off business rule for this reconciliation. Evidence: pass-wise counts and permitted sample outcomes. Exclusive does not automatically imply all duplicates match or break reasons must clear.

## BAU vs EZ comparison and environment drift
AS-IS: both configurations and deployment versions. TO-BE: the approved business behavior and accepted implementation differences. Evidence: like-for-like run IDs, COB dates, record counts, code versions, reconciliation outputs. Do not assume BAU is the source of truth; record unknowns when no authoritative specification exists.
