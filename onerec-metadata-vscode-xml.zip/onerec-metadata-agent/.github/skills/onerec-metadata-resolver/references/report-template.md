# OneRec metadata as-is versus to-be report

## Scope
Recon / feed / environment / COB or run / incident ID / input artifact versions.

## What we have (as-is)
Observed configuration values and capture provenance. Keep only relevant fields.

## What we need (to-be)
Expected assertions with approved owner/reference/effective version. Flag any unverified expected values.

## Gap matrix

| Field path | Actual | Expected | Authority | Status | Potential impact | Evidence needed |
|---|---|---|---|---|---|---|
| metadata.feed.delimiter | pipe | comma | SYNTHETIC-SPEC-001 (demo only) | gap_requires_review | Parser may split rows incorrectly | Confirm source-file layout and parsing output |

## Runtime corroboration
Explicitly list observed row counts, record samples, audit evidence, parser outcomes and log excerpts only when provided. Do not infer them from metadata.

## RCA
- Status: confirmed / probable / inconclusive.
- Reason: actual config differs from approved rule, plus independently observed effect.
- Competing hypotheses: metadata, source feed, code path, schedule, environment.

## Proposed correction (review only)
Field path, current value, proposed value, source and version, dependency risks, owner approval, re-run/verification plan, rollback reference. No automatic write or patch execution.

## Open questions
List minimum evidence needed to confirm cause and complete change approval.
