# Native XML Metadata Investigation

## Input contract

Accept a well-formed sanitized **actual.xml** in the original OneRec export structure. When available, supply **expected.xml** from the same recon/feed/environment or an independently approved target configuration. There is **no assumed standard OneRec XML schema** in this starter. Do not rename tags or convert values to guessed JSON keys.

## Evidence classification

- An approved contract or change request is authoritative only after verifying its provenance outside this tool.
- A successful previous XML export is comparative evidence; success of a run does not prove all metadata values were correct.
- A peer feed's XML is a hypothesis source, not a valid expected state without confirmed equivalence.
- When no expected XML exists, use inventory mode and report that correctness cannot be assessed.

## Safe CLI usage

```sh
python tools/validate_metadata.py --actual examples/actual.xml --expected examples/expected.xml --output reports/xml-gap-report.json
python tools/validate_metadata.py --actual examples/actual.xml --output reports/xml-inventory.json
python tools/validate_metadata.py --actual examples/actual.xml --expected examples/expected.xml --xml-mode full --output reports/full-diff.json
```

## XML difference semantics

- Compare XML root, attributes, element presence and nonempty trimmed text values. Ignore indentation-only text. Attribute order is irrelevant.
- Compare repeated siblings using a unique stable identifier (`id`, `name`, `key`, `code`, `feedId`, `feed_id`, `reconId`, `recon_id`) where present; otherwise use position, with an explicit warning about order sensitivity.
- Preserve XML namespaces in paths. Do not interpret identical local names from different namespaces as equivalent.
- `subset` (default) checks paths present in expected only, suitable for a targeted TO-BE template. `full` also reports additional AS-IS paths.
- A different XML root produces `incompatible_xml_roots`, not a config fix proposal.
- No XSD validation, cross-field semantics or runtime causality is inferred. If the export uses complex mixed XML content or a transformation expression stored as nested markup, validate against an approved schema and assess manually.
- Reject DTD/ENTITY declarations and files above 10 MB. Never parse remote resources or alter source files.

## Investigation output

Explain each difference with its exact XPath-like field path, observed value, target/reference value, source authority and confidence. Before recommending a change, verify the documents belong to the same recon/feed/environment and obtain runtime evidence where possible. Mark candidate fixes as **review-only** and never invoke Oracle writes.
