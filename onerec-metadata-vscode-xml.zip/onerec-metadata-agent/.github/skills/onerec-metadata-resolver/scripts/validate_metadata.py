#!/usr/bin/env python3
"""Offline OneRec metadata validation for XML (native) and legacy JSON rules."""
import argparse
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

_MISSING = object()
OPERATORS = {"equals", "not_equals", "one_of", "required", "absent"}
SEVERITIES = {"high", "medium", "low"}


def get_value(document, dotted_path):
    """Resolve a restricted dict-only path; no expressions, wildcards or evaluation."""
    if not isinstance(dotted_path, str) or not dotted_path or not all(
        part and part.replace("_", "").replace("-", "").isalnum()
        for part in dotted_path.split(".")
    ):
        return _MISSING
    value = document
    for part in dotted_path.split("."):
        if not isinstance(value, dict) or part not in value:
            return _MISSING
        value = value[part]
    return value


def is_populated(value):
    return value is not _MISSING and value is not None and value != "" and value != [] and value != {}


def check_rule(actual, rule):
    path = rule.get("path")
    op = rule.get("op")
    severity = rule.get("severity", "medium")
    result = {
        "path": path,
        "operator": op,
        "severity": severity,
        "source_ref": rule.get("source_ref"),
        "rationale": rule.get("rationale"),
    }
    if not isinstance(path, str) or not path.startswith("metadata.") or op not in OPERATORS or severity not in SEVERITIES:
        return {**result, "status": "unknown", "reason": "Invalid rule path, operator or severity"}
    condition = rule.get("when")
    if condition is not None:
        if not isinstance(condition, dict) or not isinstance(condition.get("path"), str) or "equals" not in condition:
            return {**result, "status": "unknown", "reason": "Invalid conditional rule"}
        condition_value = get_value(actual, condition["path"])
        if condition_value is _MISSING:
            return {**result, "status": "unknown", "reason": "Condition field missing in actual metadata"}
        if condition_value != condition["equals"]:
            return {**result, "status": "not_applicable", "reason": "Rule condition does not apply"}
    actual_value = get_value(actual, path)
    present = actual_value is not _MISSING
    result["actual"] = actual_value if present else "<MISSING>"
    if "value" in rule:
        result["expected"] = rule["value"]
    if op in {"equals", "not_equals", "one_of"} and "value" not in rule:
        return {**result, "status": "unknown", "reason": "Expected value not supplied"}
    if op == "one_of" and not isinstance(rule["value"], list):
        return {**result, "status": "unknown", "reason": "one_of requires a list"}
    if op == "required":
        aligned = is_populated(actual_value)
    elif op == "absent":
        aligned = not present or actual_value is None
    elif not present:
        aligned = False
    elif op == "equals":
        aligned = actual_value == rule["value"]
    elif op == "not_equals":
        aligned = actual_value != rule["value"]
    else:
        aligned = actual_value in rule["value"]
    return {**result, "status": "aligned" if aligned else "gap_requires_review", "reason": "Rule check only; runtime causality not established"}


def validate(actual, expected):
    if not isinstance(actual, dict) or not isinstance(expected, dict):
        raise ValueError("Both inputs must be JSON objects")
    actual_scope, expected_scope = actual.get("scope"), expected.get("scope")
    if not isinstance(actual_scope, dict) or not isinstance(expected_scope, dict):
        return {"status": "invalid_scope", "read_only": True, "error": "Both documents must contain a scope object"}
    for field in ("recon_id", "feed_id", "environment"):
        a, e = actual_scope.get(field), expected_scope.get(field)
        if not is_populated(a) or not is_populated(e) or str(a) != str(e):
            return {"status": "invalid_scope", "read_only": True, "error": "Scope missing or differs: " + field,
                    "actual_scope": actual_scope, "expected_scope": expected_scope}
    rules = expected.get("rules")
    if not isinstance(rules, list) or not rules:
        return {"status": "no_verified_expectations", "read_only": True, "scope": actual_scope,
                "error": "Expected state needs at least one explicit rule"}
    authority = expected.get("authority") or {}
    claimed_approved = isinstance(authority, dict) and authority.get("status") == "approved" and all(
        is_populated(authority.get(k, _MISSING)) for k in ("type", "reference", "owner")
    )
    checks = []
    for index, rule in enumerate(rules):
        if not isinstance(rule, dict):
            checks.append({"index": index, "status": "unknown", "reason": "Rule must be a JSON object"})
        else:
            checks.append({"index": index, **check_rule(actual, rule)})
    summary = {status: sum(c["status"] == status for c in checks) for status in
               ("aligned", "gap_requires_review", "unknown", "not_applicable")}
    if not claimed_approved:
        status = "unverified_expected_state"
    elif summary["unknown"]:
        status = "incomplete_validation"
    elif summary["gap_requires_review"]:
        status = "gaps_require_review"
    else:
        status = "aligned_to_documented_expectations"
    return {
        "status": status,
        "read_only": True,
        "scope": actual_scope,
        "authority": {"claim": authority, "independently_verified": False},
        "summary": summary,
        "checks": checks,
        "causality": "not_established",
        "note": "A difference is not proof of defect. Verify expected-state approval and runtime evidence separately."
    }



MAX_XML_BYTES = 10 * 1024 * 1024
KEY_ATTRIBUTES = ("id", "name", "key", "code", "feedId", "feed_id", "reconId", "recon_id")


def parse_xml(path):
    """Read a local XML file, rejecting DTD/ENTITY to avoid external/expanded entities."""
    if path.stat().st_size > MAX_XML_BYTES:
        raise ValueError("XML file exceeds the 10 MB demo limit; provide a sanitized scoped export")
    raw = path.read_bytes()
    if re.search(rb"<!\s*(?:DOCTYPE|ENTITY)\b", raw, re.I):
        raise ValueError("XML containing DTD or ENTITY declarations is not supported")
    try:
        return ET.fromstring(raw)
    except ET.ParseError as exc:
        raise ValueError("Invalid XML: " + str(exc)) from exc


def xml_tag(name):
    """Preserve namespace URIs without relying on source prefix spellings."""
    return name


def child_paths(parent, parent_path, warnings):
    grouped = {}
    for child in parent:
        grouped.setdefault(child.tag, []).append(child)
    out = []
    for tag, children in grouped.items():
        chosen = None
        for attr in KEY_ATTRIBUTES:
            vals = [c.get(attr) for c in children]
            if all(v is not None and len(v) <= 100 for v in vals) and len(set(vals)) == len(vals):
                chosen = attr
                break
        if chosen is None and len(children) > 1:
            warnings.add(f"Repeated unkeyed XML elements at {parent_path}/{xml_tag(tag)} compared by position; reordered siblings may appear different")
        for i, child in enumerate(children, start=1):
            part = xml_tag(tag)
            if chosen:
                part += f"[@{chosen}={child.attrib[chosen]!r}]"
            elif len(children) > 1:
                part += f"[{i}]"
            out.append((child, f"{parent_path}/{part}"))
    return out


def flatten_xml(root):
    """Flatten structure, attributes and leaf values into stable explicit field paths."""
    result = {}
    warnings = set()

    def visit(node, path):
        result[path + '/#exists'] = True
        for attr, value in sorted(node.attrib.items()):
            result[path + '/@' + attr] = value
        value = (node.text or '').strip()
        if value:
            result[path + '/#text'] = value
        for child, cpath in child_paths(node, path, warnings):
            visit(child, cpath)

    visit(root, '/' + xml_tag(root.tag))
    return result, sorted(warnings)


def compare_xml(actual_root, expected_root=None, mode='subset', expected_basis='unverified'):
    """Structural XML comparison; changes are observations, not confirmed defects."""
    actual_map, actual_warnings = flatten_xml(actual_root)
    if expected_root is None:
        return {
            'status': 'no_expected_state', 'read_only': True,
            'format': 'xml', 'comparison_mode': 'inventory',
            'root': actual_root.tag, 'actual_field_paths': len(actual_map),
            'warnings': actual_warnings,
            'causality': 'not_established',
            'note': 'An XML export alone does not establish what is correct. Supply approved expected XML or an approved requirement.'
        }
    if actual_root.tag != expected_root.tag:
        return {
            'status': 'incompatible_xml_roots', 'read_only': True,
            'format': 'xml', 'actual_root': actual_root.tag,
            'expected_root': expected_root.tag,
            'causality': 'not_established',
            'note': 'Align document types and scope before comparing XML.'
        }
    if mode not in {'subset', 'full'}:
        raise ValueError('XML comparison mode must be subset or full')
    expected_map, expected_warnings = flatten_xml(expected_root)
    paths = sorted(set(expected_map) if mode == 'subset' else set(expected_map) | set(actual_map))
    findings = []
    aligned = 0
    for path in paths:
        present_a = path in actual_map
        present_e = path in expected_map
        if present_a and present_e and actual_map[path] == expected_map[path]:
            aligned += 1
            continue
        if not present_a:
            kind = 'missing_in_actual'
        elif not present_e:
            kind = 'additional_in_actual'
        else:
            kind = 'value_difference'
        findings.append({
            'path': path, 'difference_type': kind,
            'actual': actual_map.get(path, '<MISSING>'),
            'expected': expected_map.get(path, '<NOT_SPECIFIED>'),
            'status': 'difference_requires_review'
        })
    warnings = sorted(set(actual_warnings + expected_warnings))
    warnings.append('Manually verify recon/feed/environment scope: generic XML paths do not establish compatible reconciliation context')
    if len(findings) > 2000:
        warnings.append(f'Too many differences: only the first 2000 of {len(findings)} are included')
    return {
        'status': 'differences_require_review' if findings else 'structurally_aligned',
        'read_only': True,
        'format': 'xml', 'comparison_mode': mode,
        'expected_basis': expected_basis,
        'authority_independently_verified': False,
        'summary': {'aligned_field_paths': aligned, 'difference_paths': len(findings)},
        'findings': findings[:2000],
        'truncated': len(findings) > 2000,
        'warnings': warnings, 'causality': 'not_established',
        'note': 'XML comparison shows observed differences only. A difference is not proof of defect or root cause; confirm expected-state authority and runtime evidence.'
    }


def main():
    parser = argparse.ArgumentParser(description="Read-only OneRec metadata comparison: native XML or legacy JSON rules")
    parser.add_argument("--actual", required=True, help="Sanitized current/AS-IS XML or legacy JSON")
    parser.add_argument("--expected", help="Target/reference XML or approved JSON rule assertions; optional for XML inventory")
    parser.add_argument("--output", required=True, help="Destination for a new JSON report")
    parser.add_argument("--xml-mode", choices=("subset", "full"), default="subset",
                        help="subset: compare only paths specified by expected XML (default); full: include extra actual paths")
    parser.add_argument("--expected-basis", choices=("unverified", "working-reference", "approved-claim"),
                        default="unverified", help="Describe source of expected XML; no approval is verified by the tool")
    args = parser.parse_args()
    actual_path, out_path = Path(args.actual).resolve(), Path(args.output).resolve()
    expected_path = Path(args.expected).resolve() if args.expected else None
    paths = [actual_path, out_path] + ([expected_path] if expected_path else [])
    if len(set(paths)) != len(paths):
        parser.error("Actual, expected and output must be different paths")
    if not actual_path.is_file():
        parser.error("Missing input: " + str(actual_path))
    if expected_path and not expected_path.is_file():
        parser.error("Missing expected input: " + str(expected_path))
    if actual_path.suffix.lower() not in ('.json', '.xml'):
        parser.error("--actual must be .xml or .json")
    if actual_path.suffix.lower() == '.json' and expected_path is None:
        parser.error("Legacy JSON rule validation requires --expected")
    if expected_path and expected_path.suffix.lower() != actual_path.suffix.lower():
        parser.error("Use matching file formats: XML with XML, or JSON with JSON; do not silently translate unknown schemas")
    try:
        if actual_path.suffix.lower() == '.xml':
            actual = parse_xml(actual_path)
            expected = parse_xml(expected_path) if expected_path else None
            report = compare_xml(actual, expected, args.xml_mode, args.expected_basis)
        else:
            actual = json.loads(actual_path.read_text(encoding='utf-8'))
            expected = json.loads(expected_path.read_text(encoding='utf-8'))
            report = validate(actual, expected)
    except (ValueError, UnicodeDecodeError, OSError) as exc:
        parser.error(str(exc))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report, indent=2, ensure_ascii=True) + "\n", encoding='utf-8')
    print(json.dumps(report, indent=2, ensure_ascii=True))


if __name__ == '__main__':
    main()
