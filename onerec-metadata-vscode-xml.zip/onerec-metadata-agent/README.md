# OneRec Metadata Resolver v3 - Native XML support (No MCP)

Use VS Code + organization-approved GitHub Copilot Agent Mode to compare sanitized OneRec XML metadata without changing the source documents. The generated report is JSON, but **input XML is read directly**; you do not need JSON versions of your configuration. Legacy JSON rule examples are retained.

## Quick start (from repository root)

Python 3.9+; standard library only, no pip install needed.

```sh
python tools/validate_metadata.py --actual examples/actual.xml --expected examples/expected.xml --output reports/xml-gap-report.json
python -m unittest discover -s tests -v
```

For a scoped XML inspection with no trustworthy TO-BE configuration yet:

```sh
python tools/validate_metadata.py --actual examples/actual.xml --output reports/xml-inventory.json
```

For a complete XML comparison including fields **only** in the actual document:

```sh
python tools/validate_metadata.py --actual examples/actual.xml --expected examples/expected.xml --xml-mode full --expected-basis working-reference --output reports/full-xml-diff.json
```

## Important semantics

- **actual.xml** = exported current/AS-IS configuration.
- **expected.xml** = target or reference configuration; do not assume it is approved unless independently verified.
- **subset mode** (default) checks paths explicitly present in expected.xml; additional actual fields are ignored.
- **full mode** reports paths missing in either document.
- Elements, attributes, and nonempty leaf text are compared. Whitespace-only indentation is ignored. Keyed collections are compared by recognized stable attributes where available; unkeyed repeated elements are positional and may need manual review.
- Generic XML comparison is not schema-aware: namespaces are preserved, but field meaning, environment compatibility, actual source contracts, and causality require engineer review.
- XML with DTD/ENTITY declarations is rejected; sample limit 10 MB; no external calls, SQL or Oracle/MCP access.

Sample XML is **synthetic** and is not OneRec's actual schema. Never upload unsanitized Citi production metadata to unapproved platforms.

## Copilot

Select `metadata-resolver` under Copilot Agent Mode if enabled by the organization. Ask:

> Use the OneRec Metadata Resolver Skill to inspect examples/actual.xml versus examples/expected.xml. Run the read-only XML validator; list differences by element/attribute path; distinguish observation from verified defect; propose review-only corrections. Do not modify inputs or connect to any service.

If the Copilot extension does not recognize the agent metadata, explicitly open `.github/agents/metadata-resolver.agent.md` and `.github/skills/onerec-metadata-resolver/SKILL.md` as context.

## Legacy JSON rules

```sh
python tools/validate_metadata.py --actual examples/actual.json --expected examples/expected.json --output reports/json-gap-report.json
```

This older mode validates an approved-claim rules document against a normalized JSON export; it is retained for backwards compatibility.
