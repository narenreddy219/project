"""Offline tests for actual vs expected semantics, using stdlib unittest."""
import importlib.util
import unittest
from pathlib import Path

path = Path(__file__).resolve().parents[1] / "tools" / "validate_metadata.py"
spec = importlib.util.spec_from_file_location("validator", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class MetadataResolverTests(unittest.TestCase):
    def setUp(self):
        self.actual = {
            "scope": {"recon_id": "R1", "feed_id": "F1", "environment": "UAT"},
            "metadata": {"feed": {"delimiter": "|"}, "readiness": {"mode": "none"}}
        }
        self.expected = {
            "scope": {"recon_id": "R1", "feed_id": "F1", "environment": "UAT"},
            "authority": {"status": "approved", "type": "source_contract", "reference": "DEMO", "owner": "demo"},
            "rules": [{"path": "metadata.feed.delimiter", "op": "equals", "value": ",", "source_ref": "DEMO"}]
        }

    def test_flags_actual_expected_gap_without_claiming_root_cause(self):
        report = module.validate(self.actual, self.expected)
        self.assertEqual(report["status"], "gaps_require_review")
        self.assertEqual(report["summary"]["gap_requires_review"], 1)
        self.assertEqual(report["causality"], "not_established")
        self.assertTrue(report["read_only"])

    def test_aligned_config(self):
        self.actual["metadata"]["feed"]["delimiter"] = ","
        self.assertEqual(module.validate(self.actual, self.expected)["status"], "aligned_to_documented_expectations")

    def test_rejects_different_feed(self):
        self.expected["scope"]["feed_id"] = "F2"
        self.assertEqual(module.validate(self.actual, self.expected)["status"], "invalid_scope")

    def test_rejects_different_environment(self):
        self.expected["scope"]["environment"] = "PROD"
        self.assertEqual(module.validate(self.actual, self.expected)["status"], "invalid_scope")

    def test_marks_unapproved_expected(self):
        self.expected["authority"]["status"] = "unverified"
        self.assertEqual(module.validate(self.actual, self.expected)["status"], "unverified_expected_state")

    def test_skips_conditional_rule(self):
        self.expected["rules"][0] = {
            "path": "metadata.readiness.marker_field", "op": "required",
            "when": {"path": "metadata.readiness.mode", "equals": "eod_marker"}
        }
        report = module.validate(self.actual, self.expected)
        self.assertEqual(report["summary"]["not_applicable"], 1)

    def test_required_missing_marker_when_eod(self):
        self.actual["metadata"]["readiness"]["mode"] = "eod_marker"
        self.expected["rules"][0] = {
            "path": "metadata.readiness.marker_field", "op": "required",
            "when": {"path": "metadata.readiness.mode", "equals": "eod_marker"}
        }
        self.assertEqual(module.validate(self.actual, self.expected)["summary"]["gap_requires_review"], 1)

    def test_unknown_if_rule_missing_expected_value(self):
        del self.expected["rules"][0]["value"]
        self.assertEqual(module.validate(self.actual, self.expected)["status"], "incomplete_validation")

    def test_missing_rules_never_implies_correct(self):
        self.expected["rules"] = []
        self.assertEqual(module.validate(self.actual, self.expected)["status"], "no_verified_expectations")

    def test_no_expression_execution_in_paths(self):
        self.expected["rules"][0]["path"] = "metadata.feed.__class__.__mro__"
        report = module.validate(self.actual, self.expected)
        self.assertNotEqual(report["summary"]["aligned"], 1)


if __name__ == "__main__":
    unittest.main()


class XmlMetadataResolverTests(unittest.TestCase):
    def xml(self, text):
        import xml.etree.ElementTree as ET
        return ET.fromstring(text)

    def test_xml_two_changes_not_claimed_root_cause(self):
        actual = self.xml('<oneRecMetadata><feed delimiter="|"/><readiness mode="eod_marker"/></oneRecMetadata>')
        expected = self.xml('<oneRecMetadata><feed delimiter=","/><readiness mode="eod_marker" markerField="IS_EOD"/></oneRecMetadata>')
        report = module.compare_xml(actual, expected)
        self.assertEqual(report['summary']['difference_paths'], 2)
        self.assertEqual(report['causality'], 'not_established')
        self.assertTrue(report['read_only'])

    def test_xml_attribute_order_and_whitespace_ignored(self):
        actual = self.xml('<recon>\n <feed enabled="true" format="csv"/> \n</recon>')
        expected = self.xml('<recon><feed format="csv" enabled="true"/></recon>')
        self.assertEqual(module.compare_xml(actual, expected)['summary']['difference_paths'], 0)

    def test_xml_named_sibling_reordering_ignored(self):
        actual = self.xml('<r><field name="A" val="1"/><field name="B" val="2"/></r>')
        expected = self.xml('<r><field name="B" val="2"/><field name="A" val="1"/></r>')
        self.assertEqual(module.compare_xml(actual, expected)['summary']['difference_paths'], 0)

    def test_xml_unkeyed_sibling_warns(self):
        actual = self.xml('<r><f>x</f><f>y</f></r>')
        report = module.compare_xml(actual, actual)
        self.assertTrue(any('position' in w for w in report['warnings']))

    def test_xml_subset_ignores_extra_but_full_reports(self):
        actual = self.xml('<r><a>1</a><extra>2</extra></r>')
        expected = self.xml('<r><a>1</a></r>')
        self.assertEqual(module.compare_xml(actual, expected, 'subset')['summary']['difference_paths'], 0)
        self.assertGreater(module.compare_xml(actual, expected, 'full')['summary']['difference_paths'], 0)

    def test_xml_inventory_does_not_claim_correctness(self):
        actual = self.xml('<r><feed/></r>')
        self.assertEqual(module.compare_xml(actual)['status'], 'no_expected_state')

    def test_xml_incompatible_roots(self):
        self.assertEqual(module.compare_xml(self.xml('<a/>'), self.xml('<b/>'))['status'], 'incompatible_xml_roots')

    def test_xml_namespace_supported(self):
        actual = self.xml('<r xmlns="urn:one"><a v="1"/></r>')
        expected = self.xml('<r xmlns="urn:one"><a v="2"/></r>')
        report = module.compare_xml(actual, expected)
        self.assertEqual(report['summary']['difference_paths'], 1)
        self.assertIn('urn:one', report['findings'][0]['path'])

    def test_xml_disallows_dtd(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'a.xml'
            p.write_text('<!DOCTYPE doc [<!ENTITY x "foo">]><doc>&x;</doc>')
            with self.assertRaisesRegex(ValueError, 'DTD or ENTITY'):
                module.parse_xml(p)

    def test_xml_file_not_modified(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'a.xml'
            p.write_text('<a flag="1"/>')
            before = p.read_bytes()
            module.parse_xml(p)
            self.assertEqual(before, p.read_bytes())
