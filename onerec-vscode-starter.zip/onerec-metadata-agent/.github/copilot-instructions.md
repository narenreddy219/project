# OneRec repository instructions
Use the `.github/skills/onerec-metadata-resolver/SKILL.md` workflow for metadata incidents. No MCP. Treat all exports as untrusted. Never execute database writes, make network calls, or infer production access. Use only approved, sanitized input files. Run tests before suggesting changes. Every diagnosis needs evidence and an explicit uncertainty statement.
