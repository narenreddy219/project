# Sanitized metadata export contract

Supply JSON objects with `recon_id`, `feed_id`, `environment`, `source`, `format`, `delimiter`, `has_header`, `completion_mode`, `eod_marker_field`, `cpp`, `scheduler` and `matching`. These are **sample export field names**, not verified OneRec Oracle column names. Export mapping must be reviewed by the OneRec team.

Current and baseline files must refer to the same recon ID and feed ID. `baseline` must be approved separately and identified in the incident evidence. Do not use real customer data, secrets or production credentials. Baseline can be another approved environment snapshot, but cross-environment differences are not necessarily errors.

Allowed `completion_mode`: `marker`, `trailer`, `file_pair`, `none`. `marker` requires an `eod_marker_field`; `file_pair` is for paired readiness markers such as .dat/.ok, when applicable. Other domain checks require separate verified policy definitions.
