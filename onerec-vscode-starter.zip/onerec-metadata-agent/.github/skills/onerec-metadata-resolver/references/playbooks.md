# OneRec investigation playbooks

## Delimiter / BAU versus EZ
Check current delimiter against approved baseline and actual file specification. Inspect parser configuration and any hardcoded delimiter in permitted source. A difference alone does not establish root cause. Verify with representative sanitized records.

## EOD / trailer / marker
Check completion_mode and eod_marker_field. An EOD marker with count is different from a synthetic trailer. Never invent EOM messages or commit Kafka offsets. Check completeness semantics with source owners.

## CPP transformation
Compare transformation count and mappings with approved metadata. Do not infer transformation correctness from count alone. Identify possible code-level issues separately.

## Scheduler / COB / T+1 T+2
Compare schedule and gating metadata; confirm business calendar and holiday semantics from approved requirements before proposing a fix.

## Inclusive / exclusive matching
Inspect matching pass flags, duplicate treatment and break reason definitions; never assume exclusive mode universally clears duplicate break reasons.

## File watcher
Review readiness configuration, .dat/.ok pairing, source paths and idempotency rules. Distinguish configuration mismatch from code behavior.
