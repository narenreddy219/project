#!/usr/bin/env python3
"""Offline, read-only metadata diff and basic completeness checks."""
import argparse
import json
from pathlib import Path

FIELDS = ("source", "format", "delimiter", "has_header", "completion_mode", "eod_marker_field", "cpp", "scheduler", "matching")

def validate(current, baseline):
    findings = []
    for key in ("recon_id", "feed_id"):
        if not current.get(key) or not baseline.get(key):
            findings.append({"code": "MISSING_ID", "severity": "error", "field": key, "detail": "Both exports require this identifier"})
        elif str(current[key]) != str(baseline[key]):
            findings.append({"code": "SCOPE_MISMATCH", "severity": "error", "field": key, "detail": "Current and baseline identify different entities"})
    if any(f["severity"] == "error" for f in findings):
        return {"status": "invalid_scope", "findings": findings, "read_only": True}
    for key in FIELDS:
        if key not in current or key not in baseline:
            findings.append({"code": "MISSING_FIELD", "severity": "warning", "field": key, "detail": "Absent from current or baseline; cannot compare"})
        elif current[key] != baseline[key]:
            findings.append({"code": "CONFIG_DIFF", "severity": "review", "field": key, "current": current[key], "baseline": baseline[key], "detail": "Difference requires business validation; not proof of defect"})
    mode = current.get("completion_mode")
    if mode == "marker" and not current.get("eod_marker_field"):
        findings.append({"code": "MISSING_EOD_FIELD", "severity": "warning", "field": "eod_marker_field", "detail": "Marker completion requires an EOD field"})
    if mode is not None and mode not in {"marker", "trailer", "file_pair", "none"}:
        findings.append({"code": "UNKNOWN_COMPLETION_MODE", "severity": "warning", "field": "completion_mode", "detail": "Completion mode is outside sample contract"})
    return {"status": "review_required" if findings else "no_differences_found", "scope": {"recon_id": current["recon_id"], "feed_id": current["feed_id"], "environment": current.get("environment")}, "findings": findings, "read_only": True, "note": "Diffs are not verified root causes; validate against approved specifications"}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--current", required=True)
    parser.add_argument("--baseline", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    cur = json.loads(Path(args.current).read_text(encoding="utf-8"))
    base = json.loads(Path(args.baseline).read_text(encoding="utf-8"))
    if not isinstance(cur, dict) or not isinstance(base, dict):
        parser.error("Inputs must be JSON objects")
    report = validate(cur, base)
    out = Path(args.output)
    if out.resolve() in {Path(args.current).resolve(), Path(args.baseline).resolve()}:
        parser.error("Output must not overwrite input metadata")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
