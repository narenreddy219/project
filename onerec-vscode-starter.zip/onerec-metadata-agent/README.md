# OneRec Metadata Resolver (no MCP)

Offline, read-only proof of concept for VS Code Copilot Agent Mode. **All examples are synthetic.** No database connectivity or update functionality is provided.

## Start
1. Open this folder in organization-approved VS Code with Copilot Agent Mode enabled.
2. Run `python3 tools/validate_metadata.py --current examples/current.json --baseline examples/baseline.json --output reports/demo-report.json` (on Windows use `python` if needed).
3. Run `python3 -m pytest tests` if pytest is installed, or `python3 -m unittest discover` after adapting tests. No external dependencies are required by the validator.
4. In Copilot Chat, select the `metadata-resolver` custom agent if supported, then ask: `Investigate the synthetic feed metadata in examples/current.json against examples/baseline.json; explain findings and propose a correction. Do not change metadata.`

## Security
Do not use unapproved AI tools or upload confidential Citi data. This proof of concept accepts sanitized local JSON only. Approved Oracle exports and schema mappings can be added later after authorization. Output is an analysis artifact, not an Oracle update script.

## Limitations
Comparison does not prove causality; baseline provenance, field mappings and source contract must be independently confirmed. Copilot custom-agent/tool metadata support varies by enterprise version.
