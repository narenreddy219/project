import importlib.util
from pathlib import Path
spec = importlib.util.spec_from_file_location("validator", Path(__file__).resolve().parents[1] / "tools" / "validate_metadata.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

def test_detects_delimiter_difference():
    base = {"recon_id": "1", "feed_id": "f", "delimiter": ","}
    cur = {**base, "delimiter": "|"}
    report = mod.validate(cur, base)
    assert any(f["code"] == "CONFIG_DIFF" and f["field"] == "delimiter" for f in report["findings"])
    assert report["read_only"] is True

def test_refuses_cross_feed_comparison():
    a = {"recon_id": "1", "feed_id": "A"}
    b = {"recon_id": "1", "feed_id": "B"}
    assert mod.validate(a, b)["status"] == "invalid_scope"

def test_marker_requires_field():
    a = {"recon_id": "1", "feed_id": "A", "completion_mode": "marker", "eod_marker_field": None}
    assert any(f["code"] == "MISSING_EOD_FIELD" for f in mod.validate(a, a)["findings"])
